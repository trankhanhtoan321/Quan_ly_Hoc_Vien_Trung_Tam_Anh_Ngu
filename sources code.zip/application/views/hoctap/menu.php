<div class="row">
	<div class="col-sm-6">
		<a class="btn btn-success" href="/hoctap/themmoi"><span class="glyphicon glyphicon-plus-sign"></span> Đăng Ký</a>
		<a class="btn btn-danger" href="/hoctap"><span class="glyphicon glyphicon-remove-sign"></span> Thoát</a>
	</div>
	<div class="col-sm-6 text-right">
		<form action="/hoctap/timkiem" method="post">
			<div class="form-inline">
				<input name="search" class="form-control" placeholder="Tên Học Viên" type="text"/>
				<button class="btn btn-primary" type="submit"><span class="glyphicon glyphicon-search"></span> Tìm Kiếm</button>
			</div>
		</form>
	</div>
</div>
<br/>