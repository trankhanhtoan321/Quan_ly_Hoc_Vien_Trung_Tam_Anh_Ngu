<div class="row">
	<a class="btn btn-success" href="/khoahoc/themmoi"><span class="glyphicon glyphicon-plus-sign"></span> Thêm Mới</a>
	<?php if(isset($xuat_file_excel) && $xuat_file_excel): ?>
		<a class="btn btn-info" href="/khoahoc/report/0">Xuất File Excel</a>
	<?php endif; ?>
	<a class="btn btn-danger" href="/khoahoc"><span class="glyphicon glyphicon-remove-sign"></span> Thoát</a>
</div>
<br/>