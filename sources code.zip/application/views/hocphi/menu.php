<div class="row">
	<div class="col-sm-6">
		<a class="btn btn-success" href="/hocphi/themmoi"><span class="glyphicon glyphicon-plus-sign"></span> Đóng Học Phí</a>
		<a class="btn btn-info" href="/hocphi"><span class="glyphicon glyphicon-th-list"></span> Danh Sách</a>
		<a class="btn btn-warning" href="/hocphi/danh_sach_no"><span class="glyphicon glyphicon-usd"></span> Danh Sách Nợ Học Phí</a>
		<a class="btn btn-danger" href="/hocphi"><span class="glyphicon glyphicon-remove-sign"></span> Thoát</a>
	</div>
	<div class="col-sm-6 text-right">
		<form action="/hocphi/timkiem" method="post">
			<div class="form-inline">
				<input name="search" class="form-control" placeholder="Tên Học Viên" type="text"/>
				<button class="btn btn-primary" type="submit"><span class="glyphicon glyphicon-search"></span> Tìm Kiếm</button>
			</div>
		</form>
	</div>
</div>
<br/>