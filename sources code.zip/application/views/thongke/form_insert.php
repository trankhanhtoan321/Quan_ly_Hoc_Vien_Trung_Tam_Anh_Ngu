<h1 style="text-align:center;">Thống Kê Thu Học Phí</h1>
<form class="form-horizontal" role="form" action="" method="post">
	<div class="form-group">
		<label class="control-label col-xs-2" for="TUNGAY">Từ Ngày:</label>
		<div class="col-xs-8">
			<input type="date" class="form-control" name="TUNGAY" id="TUNGAY" required />
		</div>
		<div class="col-xs-2"></div>
	</div>
	<div class="form-group">
		<label class="control-label col-xs-2" for="DENNGAY">Đến Ngày:</label>
		<div class="col-xs-8">
			<input type="date" class="form-control" name="DENNGAY" id="DENNGAY" required />
		</div>
		<div class="col-xs-2"></div>
	</div>
	<div class="form-group"> 
		<div class="col-xs-offset-2 col-xs-8">
			<button type="submit" class="btn btn-success">
				<span class="glyphicon glyphicon-plus-sign"></span>
			Xem Sao Kê</button>
		</div>
		<div class="col-xs-2"></div>
	</div>
</form>